declare const styles: {
    pageViewer: string;
    CanvasZone: string;
    wrapper: string;
    h_iframe: string;
    ratio: string;
    button: string;
    label: string;
};
export default styles;
