import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IPageViewerWebPartProps {
    description: string;
}
export default class PageViewerWebPartWebPart extends BaseClientSideWebPart<IPageViewerWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
