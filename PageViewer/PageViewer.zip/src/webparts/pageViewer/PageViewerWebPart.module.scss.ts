/* tslint:disable */
require('./PageViewerWebPart.module.css');
const styles = {
  pageViewer: 'pageViewer_30f2ef5b',
  CanvasZone: 'CanvasZone_30f2ef5b',
  wrapper: 'wrapper_30f2ef5b',
  h_iframe: 'h_iframe_30f2ef5b',
  ratio: 'ratio_30f2ef5b',
  button: 'button_30f2ef5b',
  label: 'label_30f2ef5b',
};

export default styles;
/* tslint:enable */