declare interface IPageViewerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PageViewerWebPartStrings' {
  const strings: IPageViewerWebPartStrings;
  export = strings;
}
